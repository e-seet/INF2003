import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  username: string = '';
  password: string = '';
  errorMessage: string = '';

  constructor(private authService: AuthService, private router: Router) {}

  // Method to handle login
  login() {
    this.authService.login(this.username, this.password).subscribe(
      (response) => {
        if (response.status === 'success') {
          sessionStorage.setItem('user', this.username); // Store user session
          this.router.navigate(['/home']); // Redirect to home page
        } else {
          this.errorMessage = response.message;
        }
      },
      (error) => {
        console.error('Login error:', error);
        this.errorMessage = 'An error occurred during login.';
      }
    );
  }

  // Method to handle register button click
  register() {
    // Navigate to a registration page if you have one
    // For now, let's just display an alert or navigate to a '/register' route if it exists.
    this.router.navigate(['/register']); // Ensure you have a register component/page defined.
  }
}
